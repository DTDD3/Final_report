from sklearn. preprocessing import scale
from sklearn. preprocessing import StandardScaler
from sklearn. preprocessing import normalize
import numpy as np


# 随机生成矩阵
X = np.random.randint(-1000, 10000, (4, 3))
print("目标矩阵\n X = \n{}\n".format(X))

# 求 X 均值（按列）
X_mean = X.mean(axis=0)
# 求 X 方差（按列）
X_std = X.std(axis=0)

# 小数缩放标准化（十进制归一化）
X_T = X

while np.max(X_T) > 1 or np.max(X_T) < -1:
    X_T = X_T / 10

print("小数缩放标准化\n X_T = \n{}\n\n".format(X_T))

# 数学公式计算法 标准化 X
X_1 = (X-X_mean)/X_std

# 调用scale函数 标准化 X
X_2 = scale(X)

# 定义类 scaler
scaler = StandardScaler()

# 标准差 标准化 X
X_3 = scaler.fit_transform(X)

# L2-归一化
X_L2 = normalize(X)


# 查看计算结果
print("均值 = {}\n方差 = {}\n\n公式法 min-max缩放 标准化 = \n{}"
      "\n\nscale函数 min-max缩放 标准化 ""= \n{}\n\n标准差 标准化 = \n{}"
      "\n\nL2-归一化 = \n{}\n\n".format(X_mean, X_std, X_1, X_2, X_3, X_L2))
