import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer


# '''
#     single
# '''
# # 均值 mean  中位数 median  众数 most_frequent  字符串/数字处理 constant
# imp = SimpleImputer(missing_values=np.nan, strategy='mean')
# imp.fit([[1, 2], [np.nan, 3], [7, 6]])
# X_Lack_1 = [[np.nan, 2], [6, np.nan], [7, 6]]
# X_Lack_2 = imp.transform(X_Lack_1)
# # imp.fit_transform([[1, 2], [np.nan, 3], [7, 6]])
#
# # 查看计算结果
# print("{}\n\n{}\n\n".format(X_Lack_1, X_Lack_2))


'''
    Multivariate
'''
from sklearn.experimental import enable_iterative_imputer
from sklearn.impute import IterativeImputer
imp = IterativeImputer(max_iter=10, random_state=0)
imp.fit([[1, 2], [3, 6], [4, 8], [np.nan, 3], [7, np.nan]])

X_test = [[np.nan, 2], [6, np.nan], [np.nan, 6]]
print(np.round(imp.transform(X_test)))


