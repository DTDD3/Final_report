import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer


df = pd.DataFrame([["XXL", 8, "black", "class 1", 22],
["L", np.nan, "gray", "class 2", 20],
["XL", 10, "blue", "class 2", 19],
["M", np.nan, "orange", "class 1", 17],
["M", 11, "green", "class 3", np.nan],
["M", 7, "red", "class 1", 22]])

df.columns=["size", "price", "color", "class", "boh"]

print(df, end='\n\n')

imp = SimpleImputer(missing_values=np.nan, strategy="mean")

df["price"] = imp.fit_transform(df[["price"]])
df["boh"] = imp.fit_transform(df[["boh"]])
df

print(df)
