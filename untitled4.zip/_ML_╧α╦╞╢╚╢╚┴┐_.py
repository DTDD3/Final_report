import numpy as np

np.random.seed(0)
x = np.random.random(10)
y = np.random.random(10)
x_=x-np.mean(x)
y_=y-np.mean(y)


d_Eu = np.sqrt(np.sum(np.square(x-y)))  # 欧式
d_Ma = np.sum(np.abs(x-y))      # 曼哈顿
d_Che = np.max(np.abs(x-y))     # 切比雪夫距离

X = np.vstack([x, y])
sk = np.var(X, axis=0, ddof=1)
d_SEu = np.sqrt(((x - y) ** 2 / sk).sum())      # 标准化欧氏距离

d_Co = np.dot(x,y)/(np.linalg.norm(x)*np.linalg.norm(y))    # 夹角余弦
d_Pe = np.dot(x_,y_)/(np.linalg.norm(x_)*np.linalg.norm(y_))  # 皮尔逊相关系数

print("X = {}\n\nY = {}\n\n欧式距离 = {}\n\n曼哈顿距离 = {}\n\n切比雪夫距离 = {}\n\n"
      "标准化欧式距离 = {}\n\n余弦距离 = {}\n\n皮尔逊相关系数 = {}".format(x, y, d_Eu, d_Ma, d_Che, d_SEu, d_Co, d_Pe))
