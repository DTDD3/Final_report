# import numpy as np
#
# import warnings
# warnings.filterwarnings('ignore')
#
# from sklearn.preprocessing import StandardScaler
#
# data=np.genfromtxt(fname='horse-colic.data',delimiter=' ',dtype=float,)
#
# print("最大值",np.nanmax(data))    # 获取整个矩阵的最大值 结果： 6
# print("最小值",np.nanmin(data))    # 结果：1
# print(np.nanmean(data))
#
# # 可以指定关键字参数axis来获得行最大（小）值或列最大（小）值
# # axis=0 行方向最大（小）值，即获得每列的最大（小）值
# # axis=1 列方向最大（小）值，即获得每行的最大（小）值
# # 例如
#
# print(data.max(axis=1))
# # 结果为 [3 6]
#
# # 要想获得最大最小值元素所在的位置，可以通过argmax函数来获得
# print(data.argmax(axis=1))
# # 结果为 [2 2]
# print(data)

