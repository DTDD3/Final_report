import pandas as pd
import numpy as np
from sklearn.preprocessing import Imputer

df=pd.DataFrame([["XXL", 8, "black", "class 1", 22],
["L", np.nan, "gray", "class 2", 20],
["XL", 10, "blue", "class 2", 19],
["M", np.nan, "orange", "class 1", 17],
["M", 11, "green", "class 3", np.nan],
["M", 7, "red", "class 1", 22]])

df.columns=["size", "price", "color", "class", "boh"]
print(df)

imp = Imputer(missing_values="NaN", strategy="mean",axis=0)
# 先只将处理price列的数据， 注意使用的是   df[['price']]   这样返回的是一个DataFrame类型的数据！！！！
# 2. 使用fit_transform()函数即可完成缺失值填充了
df["price"] = imp.fit_transform(df[["price"]])
df
# out:
'''
   size	price	color	class	boh
0	XXL	8.0	black	class 1	22.0
1	L	9.0	gray	class 2	20.0
2	XL	10.0	blue	class 2	19.0
3	M	9.0	orange	class 1	17.0
4	M	11.0	green	class 3	NaN
5	M	7.0	red	class 1	22.0
'''

# 直接处理price和boh两列
df[['price', 'boh']] = imp.fit_transform(df[['price', 'boh']])
df
print(df)
# out:
'''
size	price	color	class	boh
0	XXL	8.0	black	class 1	22.0
1	L	9.0	gray	class 2	20.0
2	XL	10.0	blue	class 2	19.0
3	M	9.0	orange	class 1	17.0
4	M	11.0	green	class 3	20.0
5	M	7.0	red	class 1	22.0
'''
